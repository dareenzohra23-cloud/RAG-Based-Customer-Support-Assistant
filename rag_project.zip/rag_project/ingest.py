import os
from dotenv import load_dotenv

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

load_dotenv()

# ── Configuration ────────────────────────────────────────────────────────────
PDF_PATH = "data/knowledge_base.pdf"
CHROMA_DB_DIR = "chroma_db"
COLLECTION_NAME = "support_docs"

CHUNK_SIZE = 500
CHUNK_OVERLAP = 100

# This HuggingFace model runs 100% locally — no API key, no cost.
# It's one of the most popular embedding models for RAG projects.
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def load_pdf(pdf_path: str):
    """
    Load a PDF file and return a list of Document objects.
    Each page of the PDF becomes one Document.
    """
    print(f"[1/4] Loading PDF from: {pdf_path}")

    if not os.path.exists(pdf_path):
        raise FileNotFoundError(
            f"PDF not found at '{pdf_path}'.\n"
            "Please place your PDF inside the 'data/' folder "
            "and name it 'knowledge_base.pdf'."
        )

    loader = PyPDFLoader(pdf_path)
    documents = loader.load()

    print(f"      ✓ Loaded {len(documents)} page(s).")
    return documents


def chunk_documents(documents):
    """
    Split documents into smaller chunks.

    WHY CHUNKING?
    LLMs have a token limit — we can't feed the whole PDF.
    Chunking lets us retrieve only the RELEVANT pieces per query.
    """
    print(f"[2/4] Chunking (size={CHUNK_SIZE}, overlap={CHUNK_OVERLAP})...")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
    )

    chunks = splitter.split_documents(documents)
    print(f"      ✓ Created {len(chunks)} chunk(s).")
    return chunks


def store_embeddings(chunks):
    """
    Convert chunks → embedding vectors → store in ChromaDB.

    HuggingFaceEmbeddings downloads the model on first run
    and caches it locally. Subsequent runs are instant.
    """
    print("[3/4] Generating embeddings with HuggingFace (first run downloads model)...")

    embedding_model = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},   # change to "cuda" if you have a GPU
        encode_kwargs={"normalize_embeddings": True},
    )

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embedding_model,
        persist_directory=CHROMA_DB_DIR,
        collection_name=COLLECTION_NAME,
    )

    print(
        f"      ✓ Stored {len(chunks)} chunks in ChromaDB at '{CHROMA_DB_DIR}/'.")
    return vectorstore


def main():
    print("=" * 55)
    print("   RAG Ingestion Pipeline — Starting")
    print("=" * 55)

    documents = load_pdf(PDF_PATH)
    chunks = chunk_documents(documents)
    store_embeddings(chunks)

    print("[4/4] ✅ Ingestion complete! Run main.py to start the bot.")
    print("=" * 55)


if __name__ == "__main__":
    main()
