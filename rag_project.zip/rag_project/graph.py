import os
from typing import TypedDict, Literal
from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END

from retriever import retrieve_context, format_context

load_dotenv()


# ══════════════════════════════════════════════════════════════
# 1.  STATE — shared data object that flows between all nodes
# ══════════════════════════════════════════════════════════════

class SupportState(TypedDict):
    user_query:     str    # Original question from the user
    retrieved_docs: list   # Raw Document objects from ChromaDB
    context:        str    # Formatted text from retrieved docs
    intent:         str    # "answerable" | "escalate"
    confidence:     str    # "high" | "low"
    answer:         str    # Final answer text
    source:         str    # "llm" | "human_agent"
    needs_human:    bool   # True → go to hitl_node


# ══════════════════════════════════════════════════════════════
# 2.  GROQ LLM SETUP
#     Model: llama3-8b-8192
#       - Free on Groq
#       - Very fast (runs on Groq's custom inference chips)
#       - 8192 token context window
# ══════════════════════════════════════════════════════════════

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    temperature=0.2,          # low = focused, factual answers
    api_key=os.getenv("GROQ_API_KEY"),
)


# ══════════════════════════════════════════════════════════════
# 3.  NODE FUNCTIONS
# ══════════════════════════════════════════════════════════════

def input_node(state: SupportState) -> dict:
    """
    NODE 1 — Input Node
    Retrieves the most relevant chunks from ChromaDB
    for the user's query.
    """
    print("\n[Node: input] Retrieving context from knowledge base...")

    query = state["user_query"]
    docs = retrieve_context(query)
    ctx = format_context(docs)

    print(f"  → Retrieved {len(docs)} chunk(s).")

    return {
        "retrieved_docs": docs,
        "context":        ctx,
    }


def router_node(state: SupportState) -> dict:
    """
    NODE 2 — Router Node
    Decides: answer automatically with LLM, OR escalate to human?

    THREE escalation rules:
      1. No relevant context found in knowledge base
      2. Query contains sensitive keywords (refund, legal, etc.)
      3. LLM itself says it can't answer confidently
    """
    print("[Node: router] Analysing query intent...")

    query = state["user_query"].lower()
    context = state["context"]

    # Rule 1: No context found
    no_context = (
        context == "No relevant information found in the knowledge base.")

    # Rule 2: Sensitive keywords
    escalation_keywords = [
        "refund", "lawsuit", "legal", "complaint", "compensat",
        "frustrated", "angry", "urgent", "escalate", "manager",
        "cancel my account", "data breach", "privacy",
    ]
    is_sensitive = any(kw in query for kw in escalation_keywords)

    # Rule 3: Ask LLM if it can answer confidently
    confidence_prompt = f"""You are a triage assistant. A customer asked:
"{state['user_query']}"
 
Available context from our knowledge base:
{context}
 
Can this question be answered ACCURATELY using only the context above?
Reply with exactly one word: YES or NO."""

    response = llm.invoke([HumanMessage(content=confidence_prompt)])
    llm_confident = response.content.strip().upper().startswith("YES")

    # Final decision
    if no_context or is_sensitive or not llm_confident:
        print("  → Decision: ESCALATE to human agent.")
        return {
            "intent":      "escalate",
            "confidence":  "low",
            "needs_human": True,
        }
    else:
        print("  → Decision: Answer automatically with LLM.")
        return {
            "intent":      "answerable",
            "confidence":  "high",
            "needs_human": False,
        }


def answer_node(state: SupportState) -> dict:
    """
    NODE 3 — Answer Node
    Uses Groq's LLaMA 3 + retrieved context to generate an answer.
    This is the core of RAG: the LLM is AUGMENTED with retrieved info.
    """
    print("[Node: answer] Generating answer with Groq LLaMA 3...")

    system_prompt = """You are a helpful and professional customer support assistant.
Answer the customer's question using ONLY the information in the context below.
If the context doesn't have enough information, say so honestly.
Be concise, clear, and friendly. Do not make up information."""

    user_prompt = f"""Context from knowledge base:
{state['context']}
 
Customer question: {state['user_query']}
 
Answer:"""

    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt),
    ]

    response = llm.invoke(messages)
    answer = response.content.strip()

    print("  → Answer generated.")
    return {
        "answer": answer,
        "source": "llm",
    }


def hitl_node(state: SupportState) -> dict:
    """
    NODE 4 — Human-in-the-Loop (HITL) Node
    When the router escalates, a human agent responds via the CLI.

    In a real production system this would:
      - Create a Zendesk / Freshdesk ticket
      - Send a Slack/email alert to an agent
      - Pause the workflow and wait for async human input
    """
    print("[Node: hitl] ⚠️  Escalating to human agent...")
    print("-" * 55)
    print(f"  CUSTOMER QUERY : {state['user_query']}")
    print(f"  REASON         : Low confidence or sensitive topic.")
    print("-" * 55)

    print("\n[HUMAN AGENT] Type your response to the customer:")
    human_response = input("  Agent > ").strip()

    if not human_response:
        human_response = (
            "Thank you for contacting us. Your query has been received "
            "and our team will get back to you within 24 hours."
        )

    return {
        "answer": human_response,
        "source": "human_agent",
    }


def output_node(state: SupportState) -> dict:
    """
    NODE 5 — Output Node
    Final node: formats the response with a label showing
    whether it came from the AI or a human agent.
    """
    print("[Node: output] Preparing final response...")

    label = "🤖 AI Assistant" if state["source"] == "llm" else "👤 Human Agent"

    final_response = f"{label}:\n{state['answer']}\n"

    return {"answer": final_response}


# ══════════════════════════════════════════════════════════════
# 4.  ROUTING FUNCTION
#     Called after router_node to decide the next node.
# ══════════════════════════════════════════════════════════════

def route_after_router(state: SupportState) -> Literal["answer_node", "hitl_node"]:
    if state["needs_human"]:
        return "hitl_node"
    return "answer_node"


# ══════════════════════════════════════════════════════════════
# 5.  BUILD & COMPILE THE GRAPH
# ══════════════════════════════════════════════════════════════

def build_graph():
    """
    Wires all nodes and edges together into a compiled LangGraph app.
    """
    graph = StateGraph(SupportState)

    # Add nodes
    graph.add_node("input_node",  input_node)
    graph.add_node("router_node", router_node)
    graph.add_node("answer_node", answer_node)
    graph.add_node("hitl_node",   hitl_node)
    graph.add_node("output_node", output_node)

    # Set entry point
    graph.set_entry_point("input_node")

    # Unconditional edges
    graph.add_edge("input_node",  "router_node")
    graph.add_edge("answer_node", "output_node")
    graph.add_edge("hitl_node",   "output_node")
    graph.add_edge("output_node", END)

    # Conditional edge after router
    graph.add_conditional_edges(
        "router_node",
        route_after_router,
        {
            "answer_node": "answer_node",
            "hitl_node":   "hitl_node",
        },
    )

    return graph.compile()


# ── Quick test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = build_graph()

    initial_state: SupportState = {
        "user_query":     "What are your working hours?",
        "retrieved_docs": [],
        "context":        "",
        "intent":         "",
        "confidence":     "",
        "answer":         "",
        "source":         "",
        "needs_human":    False,
    }

    result = app.invoke(initial_state)
    print("\n" + "=" * 55)
    print("FINAL ANSWER:")
    print(result["answer"])
