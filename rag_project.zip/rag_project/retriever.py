from dotenv import load_dotenv
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

load_dotenv()

# ── Must match values in ingest.py ───────────────────────────────────────────
CHROMA_DB_DIR = "chroma_db"
COLLECTION_NAME = "support_docs"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# Number of chunks to retrieve per query
TOP_K = 3


def get_retriever():
    """
    Load ChromaDB from disk and return a LangChain retriever object.
    Usage:
        retriever = get_retriever()
        docs = retriever.invoke("your question")
    """
    embedding_model = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )

    vectorstore = Chroma(
        persist_directory=CHROMA_DB_DIR,
        embedding_function=embedding_model,
        collection_name=COLLECTION_NAME,
    )

    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": TOP_K},
    )

    return retriever


def retrieve_context(query: str) -> list:
    """
    Given a user query, return the top-K relevant document chunks.

    Returns:
        List of LangChain Document objects with:
            .page_content  → text of the chunk
            .metadata      → page number, source file, etc.
    """
    retriever = get_retriever()
    docs = retriever.invoke(query)
    return docs


def format_context(docs: list) -> str:
    """
    Join retrieved chunks into a single string for the LLM prompt.
    """
    if not docs:
        return "No relevant information found in the knowledge base."

    formatted = []
    for i, doc in enumerate(docs, start=1):
        page = doc.metadata.get("page", "?")
        formatted.append(f"[Chunk {i} — Page {page}]\n{doc.page_content}")

    return "\n\n".join(formatted)


# ── Quick test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    test_query = "What is your refund policy?"
    print(f"Test query: '{test_query}'\n")

    docs = retrieve_context(test_query)

    if not docs:
        print("No results. Make sure you ran ingest.py first.")
    else:
        for i, doc in enumerate(docs, 1):
            print(f"--- Chunk {i} ---")
            print(doc.page_content)
            print()
