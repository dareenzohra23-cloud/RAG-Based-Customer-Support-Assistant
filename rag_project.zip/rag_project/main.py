import os
import sys
from dotenv import load_dotenv
from graph import build_graph, SupportState

load_dotenv()


def check_setup():
    """Check everything is ready before starting."""

    # Check Groq API key
    if not os.getenv("GROQ_API_KEY"):
        print("❌ ERROR: GROQ_API_KEY not found in .env file.")
        print("   1. Go to https://console.groq.com")
        print("   2. Create a free API key")
        print("   3. Add to .env:  GROQ_API_KEY=your_key_here")
        sys.exit(1)

    # Check ChromaDB has been created
    if not os.path.exists("chroma_db"):
        print("❌ ERROR: Knowledge base not found.")
        print("   Please run:  python ingest.py")
        sys.exit(1)

    # Warn if PDF is missing
    if not os.path.exists("data/knowledge_base.pdf"):
        print("⚠️  WARNING: data/knowledge_base.pdf not found.")
        print("   Make sure your PDF is in the data/ folder.\n")


def get_empty_state(user_query: str) -> SupportState:
    """Create a clean initial state for each query."""
    return SupportState(
        user_query=user_query,
        retrieved_docs=[],
        context="",
        intent="",
        confidence="",
        answer="",
        source="",
        needs_human=False,
    )


def print_banner():
    print("=" * 55)
    print("   🤖  RAG Customer Support Assistant")
    print("   Powered by Groq (LLaMA 3) + ChromaDB")
    print("   Embeddings: HuggingFace all-MiniLM-L6-v2")
    print("=" * 55)
    print("Type your question and press Enter.")
    print("Commands: 'quit' or 'exit' to stop.\n")


def main():
    check_setup()
    print_banner()

    # Build the graph once — reuse for all queries
    app = build_graph()

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\nGoodbye! 👋")
            break

        if not user_input:
            continue

        if user_input.lower() in ("quit", "exit", "bye"):
            print("Goodbye! 👋")
            break

        print()
        try:
            state = get_empty_state(user_input)
            result = app.invoke(state)

            print("\n" + "-" * 55)
            print(result["answer"])
            print("-" * 55 + "\n")

        except Exception as e:
            print(f"\n❌ Error: {e}")
            print("   Check your GROQ_API_KEY and try again.\n")


if __name__ == "__main__":
    main()
